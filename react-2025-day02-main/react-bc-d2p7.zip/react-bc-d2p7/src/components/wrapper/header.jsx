import React from "react";
import { NavLink } from "react-router-dom";
import logo from "./../../assets/chart.gif";
//
function Header(){
  return (
    <header>
      <img src={logo} id="logo" />
      <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>
        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>
          <li><NavLink to="/login">login</NavLink></li>
        </ul>
      </nav>
    </header>
  )
};
//
export default Header;