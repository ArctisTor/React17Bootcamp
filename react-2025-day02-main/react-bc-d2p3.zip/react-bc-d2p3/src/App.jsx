
import './styles.css'
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Home from './components/home/home';
import Employees from './components/employees/employees';
import Register from './components/register/register';
//
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/employees' element={<Employees />} />
          <Route path='/register' element={<Register />} />
        </Routes>
      </BrowserRouter>
    </>
  )
};
//
export default App
