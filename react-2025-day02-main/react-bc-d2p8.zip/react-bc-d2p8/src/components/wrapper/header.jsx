import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import logo from "./../../assets/chart.gif";
//
class Header extends Component{
  constructor(props){
    super(props);
    this.state = {validUser: localStorage.getItem('validuser')};
  };
  render(){
    return (
      <header>
        <img src={logo} id="logo" />
        <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
        <nav>
          <ul>
            <li><NavLink to="/">home</NavLink></li>
            <li><NavLink to="/register">register</NavLink></li>
            <li><NavLink to="/employees">employees</NavLink></li>
            { !this.state.validUser 
                ? <li><NavLink to="/login">login</NavLink></li>
                : <li><NavLink to="/logout">logout {this.state.validUser}</NavLink></li>
            }
          </ul>
        </nav>
      </header>
    )
  };
};
//
export default Header;