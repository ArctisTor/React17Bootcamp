import React, {Component} from "react";
//
class Main extends Component{
  render(){
    return (
      <main>
        <h2>Register for the Competition Here</h2>
        <form>
          <div>
            <label>
              Name:
                <input type="text" name="username" />
            </label>
          </div>
          <div>
            <label>
              Password:
                <input type="text" name="password" />
            </label>
          </div>
          <div>
            <input type="submit" value="Submit" />
          </div>
        </form>
      </main>
    )
  };
};
//
export default Main;
