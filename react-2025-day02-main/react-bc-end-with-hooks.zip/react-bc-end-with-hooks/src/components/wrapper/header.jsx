import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import logo from "./../../assets/chart.gif";
//
function Header(){
  const [loginStatus, setLoginStatus] = useState(false);
  const [validUser, setValidUser] = useState("");
  React.useEffect(() => {
    function init() {
      const data = localStorage.getItem('validuser'); 
      if(data){
        setLoginStatus(true);
        setValidUser(data);
      } else{
        setLoginStatus(false);
        setValidUser("");
      }
    }
    init();
}, []);
//
  const logOut = function(){   
    localStorage.removeItem('validuser');
    window.location.href = "/";    
  };
//
  return (
    <header>
      <img src={logo} id="logo" />
      <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>
        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>
          {
            !loginStatus
              ?<li><NavLink to="/login">login</NavLink></li>
              :<li onClick={logOut}>logout {validUser}</li>
          }
        </ul>
      </nav>
    </header>
  )
};
//
export default Header;