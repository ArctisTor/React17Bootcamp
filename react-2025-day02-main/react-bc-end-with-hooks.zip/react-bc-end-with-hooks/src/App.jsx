
import './styles.css'
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Home from './components/home/home';
import Employees from './components/employees/employees';
import Register from './components/register/register';
import Login from './components/login/login';
//
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/employees' element={<Employees />} />
          <Route path='/register' element={<Register />} />
          <Route path='/login' element={<Login />} />
        </Routes>
      </BrowserRouter>
    </>
  )
};
//
export default App
